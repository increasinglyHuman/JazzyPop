i'd like to work in an interrogative style- collaborating on each item - 
  i know that  will be a bit slow for you but i promise i'll try to keep up
   and to make myself useful. at this time we are working on some slow andd
   steady fixes to the quiz integration - just now we are looking at the 
  index.html dashboard - found in the kawaii-quiz-app subfolder, and the 
  many js files that link into it. specifically we are working on fixing 
  the api call - it's at current calling with an argument the api doesn't 
  like - i think the problem is on both sides - the api shouldn't be 
  barking about the size unless greater than 100, and the call should send 
  requests based on the current setting - card count - that is stored and 
  set by the user (or by default calculation) in the settings panel. There 
  are extensive dox on the project in the architecture folder. the game 
  itself is inside the kawaii quiz app folder, and the backend folder 
  contains the backend server stuff. there is a key file 
    for ssh access in ~/.ssh called poqpoq2025.pem, and the remote server 
  is ubuntu@p0qp0q.com - the game frontend on the remote server is in  
  ~/var/www/html/jazzypop/ while the game backend on the remote server is 
  in ~/jazzypop-backend.  Finally - welcome to poqpoq - where bob's are 
  loved and appreciated. and thanks for being here.