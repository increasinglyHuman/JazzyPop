## Project Details

- Working collaboratively in an interrogative style to investigate and fix API calls
- Goal is to conduct a careful forensic investigation of the backend architecture
- Need to map out process flow from script to script to API, including database access calls
- Aim to create a logical diagram verifying each component and aligning frontend API calls with backend behavior

## Project Structure

- Game located in kawaii quiz app folder
- Backend server files in backend folder
- Extensive documentation available in architecture folder

## Server Access Details

- SSH Key: ~/.ssh/poqpoq2025.pem
- Remote Server: ubuntu@p0qp0q.com
- Frontend Location: ~/var/www/html/jazzypop/
- Backend Location: ~/jazzypop-backend

## Project Culture

- Welcome to poqpoq - where bob's are loved and appreciated

## Current Development Focus

- Front-end integration of new economy manager 
- Investigating card design for cost/reward display
- Exploring gamification paradigms for cards
- Key development areas:
  * Implement consistent information display on cards
  * Design horizontal band for information presentation
  * Map out logic for points, XP, status, gems, and lives
  * Connect practice cards and challenge cards (quizzes) to economy system
- Side quest: Investigate missing zen mode quizzes and restore them
- Current card UI features text element in upper left corner for cost/benefit information
- Reviewing screenshots in currentScreens folder to analyze mobile device UI